import MetaTrader5 as mt5
from logger_config import logger

def open_trade(symbol, lot_size=0.01):
    tick = mt5.symbol_info_tick(symbol)
    if not tick:
        logger.error(f"Failed to get tick data for {symbol}")
        return False

    spread = tick.ask - tick.bid
    logger.info(f"{symbol} | Bid: {tick.bid} | Ask: {tick.ask} | Spread: {spread}")

    if spread > 0.0:
        order = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": lot_size,
            "type": mt5.ORDER_TYPE_BUY,
            "price": tick.ask,
            "deviation": 20,
            "magic": 234000,
            "comment": "Python Auto Trading Bot",
            "type_filling": mt5.ORDER_FILLING_IOC
            #"type_filling": mt5.ORDER_FILLING_FOK
            #"type_filling": mt5.ORDER_FILLING_RETURN
        }
        result = mt5.order_send(order)
        logger.info(f"Trade Order Sent: {order}")
        logger.info(f"Full Order Resonse: {result}")

        if result and result.retcode == mt5.TRADE_RETCODE_DONE:
            logger.info(f"Trade opened: {result.order}")
            return True
        else:
            logger.error(f"Trade failed: {result.retcode}")
            return False
    else:
        logger.error(f"Spread too low, no trade executed for {symbol}")


if __name__ == "__main__":
    from connect import connect, disconnect

    if connect():
        open_trade("EURUSD")  # Test trade on EURUSD
        disconnect()
# End of trade.py
